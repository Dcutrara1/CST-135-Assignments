
public class Snack extends Product 
{
	// Define Variables
	private String snackType;		// Type of snack
	
	
	// Constructor - drinkType
	public Snack(String snackType) {}	
	
	
	// Get and Set snackType
	public String snackType()
	{ return snackType; }
	public void setSnackType (String _snackType)
	{ snackType = _snackType; }
}
