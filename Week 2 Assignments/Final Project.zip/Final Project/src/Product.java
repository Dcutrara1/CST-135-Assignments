import java.awt.Image;

public abstract class Product 
{
	// Define Variables
	private String productName; 		//The name of the product
	private Image productImage; 		//Picture of product
	private String productDescription; 	//Description of the product
	private int productPrice; 			//Cost of the individual product
	private int quantityOnHand;			//Quantity of product on hand
	
	
	// Constructor - No Arguments
	Product() {}
	
	
	//Get and Set productName
	public String productName()
	{ return productName; }
	public void setProductName (String _productName)
	{ productName = _productName; }
	
	//Get and Set productImage
	public Image productImage()
	{ return productImage; }
	public void setProductImage (String _productImage)
	{ productName = _productImage; }
	
	//Get and Set productDescription
	public String productDescription()
	{ return productDescription; }
	public void setProductDescription (String _productDescription)
	{ productName = _productDescription; }
	
	//Get and Set productPrice
	public int productPrice()
	{ return productPrice; }
	public void setProductPrice (String _productPrice)
	{ productName = _productPrice; }
	
	//Get and Set quantityOnHand
	public int quantityOnHand()
	{ return quantityOnHand; }
	public void setQuantityOnHand (String _quantityOnHand)
	{ productName = _quantityOnHand; }
	
	
	//Methods	
	public void addProduct(String productName)
	{
		// Enter Method steps
	}
	
	public void reductQuantity(int quantityOnHand)
	{
		// Enter Method steps
	}
	
	public void reorderProduct()
	{
		// Enter Method steps
	}
	
	public void printProduct()
	{
		System.out.println(productName);
		System.out.println(productImage);
		System.out.println(productDescription);
		System.out.println(productPrice);
		System.out.println(quantityOnHand);
	}
}
