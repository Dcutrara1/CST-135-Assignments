
public class Gum extends Snack
{
	// Define Variables
	private String gumType;		// Type of Chips
					
		
	// Constructor - gumType
	public Gum(String gumType) 
	{ super(gumType); }
			
			
	// Get and Set gumType
	public String gumType()
	{ return gumType; }
	public void setCandyType (String _gumType)
	{ gumType = _gumType; }
	
	// Methods
}
