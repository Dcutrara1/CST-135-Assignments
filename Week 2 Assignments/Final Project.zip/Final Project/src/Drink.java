
public class Drink extends Product 
{
	// Define Variables
	private String drinkType;	// The type of beverage	
	private int calories;		// Amount of calories in the drink
	
	
	// Constructor - drinkType
	public Drink(String drinkType) {}	
		
		
	// Get and Set drinkType
	public String drinkType()
	{ return drinkType; }
	public void setDrinkType (String _drinkType)
	{ drinkType = _drinkType; }

	// Get and Set calories
	public int calories()
	{ return calories; }
	public void setCalories (int _calories)
	{ calories = _calories; }
	
}
