
public class Chips extends Snack 
{
	// Define Variables
	private String chipsType;		// Type of Chips
			
	
	// Constructor - chipsType
	public Chips(String chipsType) 
	{ super(chipsType); }
		
		
	// Get and Set snackType
	public String chipsType()
	{ return chipsType; }
	public void setCandyType (String _chipsType)
	{ chipsType = _chipsType; }
	
	// Methods
}
