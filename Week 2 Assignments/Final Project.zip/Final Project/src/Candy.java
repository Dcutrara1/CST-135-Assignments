
public class Candy extends Snack 
{
	// Define Variables
	private String candyType;		// Type of Candy
			
	
	// Constructor - drinkType
	public Candy(String snackType) 
	{ super(snackType); }
		
		
	// Get and Set snackType
	public String candyType()
	{ return candyType; }
	public void setCandyType (String _candyType)
	{ candyType = _candyType; }
	
	// Methods
}
