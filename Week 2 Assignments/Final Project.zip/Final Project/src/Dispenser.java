
public class Dispenser 
{
	// Define Variables
	private String productCatagory; 	// Various types of products
	private String productName;			// The name of the product
	private String productLocation;		// Location of the product in the Vending machine
	private int quantityPurchased;		// Number of product wanted
	private String paymentType;			// Cash or Debit/Credit Card

	
	//  Constructor - No Arguments
	Dispenser() {}
	
	
	//Get and Set productCatagory
	public String productCatagory()
	{ return productCatagory; }
	public void setProductCatagory (String _productCatagory)
	{ productCatagory = _productCatagory; }

	//Get and Set productName
	public String productName()
	{ return productName; }
	public void setProductName (String _productName)
	{ productName = _productName; }

	//Get and Set productLocation
	public String productLocation()
	{ return productLocation; }
	public void setProductLocation (String _productLocation)
	{ productLocation = _productLocation; }
	
	//Get and Set quantityPurchased
	public int quantityPurchased()
	{ return quantityPurchased; }
	public void setQuantityPurchased (int _quantityPurchased)
	{ quantityPurchased = _quantityPurchased; }
	
	//Get and Set paymentType
	public String paymentType()
	{ return paymentType; }
	public void setPaymentType (String _paymentType)
	{ paymentType = _paymentType; }
}
